#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("yyx音乐播放器");


    memberInit();
    connect(ui->GetLocalSongbtn,SIGNAL(clicked(bool)),this,SLOT(getLocalFileSlot()));
    connect(ui->playefile,SIGNAL(clicked(bool)),this,SLOT(updatePlayfilelistState()));
    connect(showlist,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(loadmusictoplayer()));
    connect(ui->PlayPauseBtn,SIGNAL(clicked(bool)),this,SLOT(updateplaypausestate()));
    connect(ui->playModecomboBox,SIGNAL(currentIndexChanged(int)),this,SLOT(updateplaymode(int)));
    connect(ui->preSongBtn,SIGNAL(clicked(bool)),contentlist,SLOT(previous()));
    connect(ui->nextSongBtn,SIGNAL(clicked(bool)),contentlist,SLOT(next()));
    connect(contentlist,SIGNAL(currentIndexChanged(int)),this,SLOT(updateplaylistbycontentlist(int)));
    connect(showlist,SIGNAL(doubleClicked(QModelIndex)),this,SLOT(updatesongTitle()));


    connect(player,SIGNAL(durationChanged(qint64)),this,SLOT(updateplaysliderange(qint64)));
    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(updateplayslideval(qint64)));
    connect(ui->playSlider,SIGNAL(sliderPressed()),this,SLOT(disconnectplayandslider()));
    connect(ui->playSlider,SIGNAL(sliderReleased()),this,SLOT(updateplayposition()));
    //时间
    connect(player,SIGNAL(durationChanged(qint64)),this,SLOT(updateTotaltime(qint64)));
    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(updateCurrenttime(qint64)));

    //音量
    connect(ui->volumeSlider,SIGNAL(valueChanged(int)),player,SLOT(setVolume(int)));

}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::memberInit()
{

   contentlist = new QMediaPlaylist;
   contentlist ->setPlaybackMode(QMediaPlaylist::Sequential);

   player = new QMediaPlayer(this);
  player ->setPlaylist(contentlist);
  player->setVolume(50);
  showlist = new QListWidget;
  showlist->setMinimumSize(500,1000);
  showlist->setMaximumSize(500,1000);
  playstate = false;
  playsongstate = false;

 ui->playSlider->setStyleSheet("QSlider::groove:horizontal{border:0px;height:4px;}"
                                "QSlider::sub-page:horizontal{background:blue;}"
                                "QSlider::add-page:horizontal{background:lightgray;}"
                               "QSlider::handle:horizontal{background:blue;width:10px;border-radius:10px;margin:-10px,-10px,-10px,-10px;}"
                               );
  ui->volumeSlider->setStyleSheet("QSlider::groove:horizontal{border:0px;height:4px;}"
                                  "QSlider::sub-page:horizontal{background:brown;}"
                                  "QSlider::add-page:horizontal{background:lightgray;}"
                                 "QSlider::handle:horizontal{background:brown;width:10px;border-radius:10px;margin:-10px,-10px,-10px,-10px;}"
                                  );

}

QString MainWindow::positiontime(qint64 n)
{
    int sec = n / 1000;
    int minute = sec /60;
    int seconds = sec % 60;
    QString timestr;
    timestr.sprintf("%02d:%02d",minute,seconds);
    return timestr;
}


void MainWindow::getLocalFileSlot()
{
    QString dirName = QFileDialog::getExistingDirectory(this,"本地歌曲","C:");
    if(dirName.isEmpty())
    {
        return;
    }
    //利用路径名得到路径
     QDir dir(dirName);
     //编写，过滤格式
     QStringList formlist;
     formlist << "*.mp3" << "*.wma" << "*.mp4";
     QFileInfoList infolist;
     infolist = dir.entryInfoList(formlist);
     QString number;
     for(int i = 0;i < infolist.count();i++)
     {
         contentlist->addMedia(QMediaContent(QUrl(infolist[i].filePath())));
         number.sprintf("【%02d】",i+1);
         showlist->addItem(number + infolist[i].fileName());
     }
     updatePlayfilelistState();
     showlist->setCurrentRow(0);
     updatesongTitle();

}

void MainWindow::updatePlayfilelistState()
{
    playstate= !playstate;
    if(playstate)
    {
        showlist->show();
        ui->playefile->setText("隐藏列表");
    }
    else
    {
        showlist->hide();
        ui->playefile->setText("显示列表");
    }
}

void MainWindow::loadmusictoplayer()
{
    int row = showlist->currentRow();
    contentlist->setCurrentIndex(row);
    playsongstate = false;
    updateplaypausestate();

}

void MainWindow::updateplaypausestate()
{
    playsongstate =!playsongstate;
    if(playsongstate)
    {
        player->play();
        ui->PlayPauseBtn->setText("暂停");
    }
    else
    {
        player->pause();
        ui->PlayPauseBtn->setText("播放");
    }
}

void MainWindow::updateplaymode(int index)
{
    switch (index)
    {
      //顺序播放
      case 0: contentlist->setPlaybackMode(QMediaPlaylist::Sequential);break;
      //循环列表
      case 1:contentlist->setPlaybackMode(QMediaPlaylist::Loop);break;
      //单曲一次
      case 2:contentlist->setPlaybackMode(QMediaPlaylist::CurrentItemOnce);break;
      //单曲循环
      case 3:contentlist->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);break;
      //随机播放
      case 4:contentlist->setPlaybackMode(QMediaPlaylist::Random);break;

    }

}

void MainWindow::updateplaylistbycontentlist(int row)
{

    showlist->setCurrentRow(row);
    updatesongTitle();
}

void MainWindow::updatesongTitle()
{
    QString str;
    QString name = showlist->currentItem()->text();
    str = "正在播放:"+name;
    ui->label->setText(str);
}

void MainWindow::updateplaysliderange(qint64 max1)
{
    ui->playSlider->setRange(0,max1-1);

}

void MainWindow::updateplayslideval(qint64 pos)
{
    ui->playSlider->setValue(pos);
}

void MainWindow::updateplayposition()
{
    player->setPosition(ui->playSlider->value());
    connect(player,SIGNAL(positionChanged(qint64)),this,SLOT(updateplayslideval(qint64)));

}

void MainWindow::disconnectplayandslider()
{
    disconnect(player,SIGNAL(positionChanged(qint64)),this,SLOT(updateplayslideval(qint64)));
}

void MainWindow::updateTotaltime(qint64 total)
{
    QString str = positiontime(total);
    ui-> totalTimeLabel->setText(str);
}

void MainWindow::updateCurrenttime(qint64 curr)
{
    QString str = positiontime(curr);
    ui-> currentTimeLabel->setText(str);
}







