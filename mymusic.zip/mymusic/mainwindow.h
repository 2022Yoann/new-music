#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMediaPlayer>
#include <QMediaPlaylist>
#include <QFileDialog>
#include <QDir>
#include <QFileInfoList>
#include <QFileInfo>
#include <QListWidget>
#include <QDebug>




QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void memberInit();

    QString positiontime(qint64 n);


public slots:
    void getLocalFileSlot(); //获取本地文件
    void updatePlayfilelistState();
    void loadmusictoplayer();
    void updateplaypausestate();
    void updateplaymode(int index);
    void updateplaylistbycontentlist(int row);
    void updatesongTitle();
    //更像滑块范围
    void updateplaysliderange(qint64 max1);
    //更新播放滑条当前
    void updateplayslideval(qint64 pos);
    //更像媒体播放位置
    void updateplayposition();
    //断开媒体播放器和滑槽
    void  disconnectplayandslider();


    //更新当前和总时间
    void updateTotaltime(qint64 total);
    void updateCurrenttime(qint64 curr);



private:
   QMediaPlayer *player;
   QMediaPlaylist *contentlist;
   QListWidget *showlist;

   bool playstate;
   bool playsongstate;




private:
    Ui::MainWindow *ui;



};
#endif // MAINWINDOW_H
